from sqlalchemy import Column, Integer, String, DateTime, Text, Float, ForeignKey
from datetime import datetime
from app.core.database import Base
class Visit(Base):
    __tablename__ = "visits"
    id = Column(Integer, primary_key=True, index=True)
    appointment_id = Column(Integer, ForeignKey("appointments.id"), nullable=False, unique=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    doctor_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    chief_complaint = Column(Text, nullable=False)
    history = Column(Text)
    examination = Column(Text)
    diagnosis = Column(String)
    plan = Column(Text)
    bp_systolic = Column(Float)
    bp_diastolic = Column(Float)
    weight = Column(Float)
    followup_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
