from sqlalchemy import Column, Integer, String, Date, DateTime, Text, ForeignKey, UniqueConstraint
from datetime import datetime
from app.core.database import Base
class Patient(Base):
    __tablename__ = "patients"
    __table_args__ = (UniqueConstraint("clinic_id", "patient_number", name="uq_clinic_patient_number"),)
    id = Column(Integer, primary_key=True, index=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    patient_number = Column(String, nullable=False, index=True)
    name = Column(String, nullable=False, index=True)
    gender = Column(String)
    date_of_birth = Column(Date)
    phone = Column(String, index=True)
    email = Column(String)
    address = Column(String)
    allergies = Column(Text)
    chronic_conditions = Column(Text)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
