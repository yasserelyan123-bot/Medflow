import Sidebar from './Sidebar'
export default function Layout({children,page,onNavigate}:{children:React.ReactNode,page:string;onNavigate:(p:string)=>void}){
 return <div className="app-shell"><Sidebar page={page} onNavigate={onNavigate}/><main className="main-content">{children}</main></div>
}