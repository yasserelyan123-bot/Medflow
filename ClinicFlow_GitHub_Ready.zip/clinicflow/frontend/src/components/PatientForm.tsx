import { useState } from 'react'
import { api } from '../api/client'
export default function PatientForm({onDone}:{onDone:()=>void}){
 const [form,setForm]=useState({clinic_id:1,branch_id:1,name:'',gender:'',phone:''}); const [error,setError]=useState('')
 async function submit(e:React.FormEvent){e.preventDefault();setError('');try{await api('/patients',{method:'POST',body:JSON.stringify(form)});onDone()}catch(e:any){setError(e.message)}}
 return <form className="form" onSubmit={submit}><input placeholder="اسم المريض" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/><input placeholder="رقم الهاتف" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/><select value={form.gender} onChange={e=>setForm({...form,gender:e.target.value})}><option value="">الجنس</option><option value="male">ذكر</option><option value="female">أنثى</option></select>{error&&<p className="error">{error}</p>}<button>حفظ المريض</button></form>
}