const items=[['dashboard','لوحة التحكم'],['patients','المرضى'],['appointments','المواعيد'],['visits','الزيارات']]
export default function Sidebar({page,onNavigate}:{page:string;onNavigate:(p:string)=>void}){
 return <aside className="sidebar"><h2>ClinicFlow</h2><nav>{items.map(([key,label])=><button key={key} className={page===key?'active':''} onClick={()=>onNavigate(key)}>{label}</button>)}</nav></aside>
}