import { useState } from 'react'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Patients from './pages/Patients'
import Appointments from './pages/Appointments'
import Visits from './pages/Visits'
export default function App(){
 const [page,setPage]=useState('dashboard')
 const pages:any={dashboard:<Dashboard/>,patients:<Patients/>,appointments:<Appointments/>,visits:<Visits/>}
 return <Layout page={page} onNavigate={setPage}>{pages[page]}</Layout>
}