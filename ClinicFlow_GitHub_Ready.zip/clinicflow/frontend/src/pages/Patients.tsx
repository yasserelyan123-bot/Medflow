import { useEffect,useState } from 'react'
import { api } from '../api/client'
import PatientForm from '../components/PatientForm'
type Patient={id:number;patient_number:string;name:string;phone?:string;gender?:string}
export default function Patients(){const [items,setItems]=useState<Patient[]>([]);const load=()=>api<Patient[]>('/patients').then(setItems);useEffect(()=>{load()},[]);return <div><h1>المرضى</h1><PatientForm onDone={load}/><div className="table">{items.map(p=><div key={p.id}><b>{p.name}</b><span>{p.patient_number}</span><span>{p.phone||'-'}</span></div>)}</div></div>}